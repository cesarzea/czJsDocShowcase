# mainDemo/resources

This folder contains resources (such as images) needed by the application. 

This file can be removed.


ToDo
-

Hecho
---------

Pendiente
----------

- El visualizador del código da un error.
- Flash al seleccionar un nodo de hijo.  
- Crear el menú de histórico.
- Mover los visualizacores a un paquete.
- Mover las vistas al raiz de las vistas.

- Documentación:
  
  - Customization manual
    - CSS
    - Markdown extends.
  
  - Manual de Desarrollo
    
    - Arquitectura.
    - Procesadores
    - Vistas
  
  - 